library(easypackages)
list.of.packages <- c("base", "blavaan", "boot", "coda", "foreign",
                      "FRACTION", "lavaan", "lme4", "MASS", "matrixcalc", "mvtnorm", "nlme",
                      "quadprog", "R2OpenBUGS", "gorica")
new.packages <- list.of.packages[!(list.of.packages %in%
                                     installed.packages()[, "Package"])]
if (length(new.packages)) install.packages(new.packages)
libraries(list.of.packages)


SEM.model <- '
Cry = ~ y1 + y2 + y3 + y4
Fld = ~ y2 + y3 + y5 + y6 + y7 + y8
Cry ~ edc + age
Fld ~ edc + age
'

data(wechsler)
wechsler$edc <-factor(wechsler$edc, levels = c("not graduated","graduated"), labels = c(0, 1))

fit <- cfa(SEM.model, data = wechsler, std.lv = TRUE)

set.seed(111)
boot <- bootstrapLavaan(fit, R = 1000, type = "nonparametric",
                        FUN = function(x) { standardizedSolution(x)$est }, verbose = TRUE, warn = TRUE)


######################Factor loadings########################


strest1 <- apply(boot, 2, mean)[1:10]
strcovmtrx1 <- cov(boot)[1:10, 1:10]
names(strest1) <- colnames(as.matrix(lavInspect(fit,
                                                "vcov.std.all")[1:10,1:10] ))
rownames(strcovmtrx1) <- colnames(as.matrix(lavInspect(fit,
                                                       "vcov.std.all")[1:10,1:10] ))
colnames(strcovmtrx1) <- colnames(as.matrix(lavInspect(fit,
                                                       "vcov.std.all")[1:10,1:10] ))
strest1

strcovmtrx1

names(strest1) <- c("L1", "L2", "L3", "L4", "L5", "L6", "L7", "L8", "L9", "L10")
gorica(x = strest1, Sigma = strcovmtrx1,
       hypothesis = "L2 > L5 & L3 > L6 & L1 > 0 & L4 > 0;
L7 > L8 & L8 > L9 & L9 > L10;
L2 > L5 & L3 > L6 & L1 > 0 & L4 > 0 & L7 > L8 & L8 > L9 & L9 > L10")


######################Regression coefficients########################



strest2 <- apply(boot, 2, mean)[11:14]
strcovmtrx2 <- cov(boot)[11:14, 11:14]
names(strest2)<-colnames(as.matrix(lavInspect(fit,
                                              "vcov.std.all")[11:14,11:14] ))
rownames(strcovmtrx2)<-colnames(as.matrix(lavInspect(fit,
                                                     "vcov.std.all")[11:14,11:14] ))
colnames(strcovmtrx2)<-colnames(as.matrix(lavInspect(fit,
                                                     "vcov.std.all")[11:14,11:14] ))
strest2

strcovmtrx2

set.seed(111)
names(strest2) <- c("G1", "G2", "G3", "G4")
gorica(x = strest2, Sigma = strcovmtrx2,
       hypothesis = "G1 > G3 & G3 > 0;
G1 > G3 & G3 > 0 & G2 > 0 & -G4 > 0")

##################Covariance between latent variables####################

strest3 <- apply(boot, 2, mean)[25]
strcovmtrx3 <- matrix(cov(boot)[23, 23])
names(strest3) <- colnames(lavInspect(fit, "vcov.std.all"))[23]
rownames(strcovmtrx3) <- colnames(lavInspect(fit, "vcov.std.all"))[23]
colnames(strcovmtrx3) <- colnames(lavInspect(fit, "vcov.std.all"))[23]
strest3


strcovmtrx3


set.seed(111)
names(strest3) <- c("w21")
gorica(x = strest3, Sigma = strcovmtrx3,
       hypothesis = "w21 = 0;
w21 > 0;
-w21 > 0", comparison = "none")


