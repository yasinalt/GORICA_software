library(easypackages)
list.of.packages <- c("base", "blavaan", "boot", "coda", "foreign",
                      "FRACTION", "lavaan", "lme4", "MASS", "matrixcalc", "mvtnorm", "nlme",
                      "quadprog", "R2OpenBUGS", "gorica")
new.packages <- list.of.packages[!(list.of.packages %in%
                                     installed.packages()[, "Package"])]
if (length(new.packages)) install.packages(new.packages)
libraries(list.of.packages)

SEM.model <- '
Cry = ~ y1 + y2 + y3 + y4
Fld = ~ y2 + y3 + y5 + y6 + y7 + y8
Cry ~ edc + age
Fld ~ edc + age
'
data(wechsler)
wechsler$edc <-factor(wechsler$edc, levels = c("not graduated","graduated"), labels = c(0, 1))

set.seed(111)
fit <- bsem(SEM.model, data = wechsler, n.chains = 3, burnin = 1000,
            sample = 10000, std.lv = TRUE)

######################Factor loadings########################

options(digits = 3)
strest1 <- standardizedSolution(fit)[1:10,4]
strcovmtrx1 <- lavInspect(fit, "vcov.std.all")[1:10, 1:10]
names(strest1) <- colnames(strcovmtrx1)
strest1

strcovmtrx1

set.seed(111)
names(strest1) <- c("L1", "L2", "L3", "L4", "L5", "L6", "L7", "L8", "L9", "L10")
gorica(x = strest1, Sigma = strcovmtrx1,
       hypothesis = "L2 > L5 & L3 > L6 & L1 > 0 & L4 > 0;
L7 > L8 & L8 > L9 & L9 > L10;
L2 > L5 & L3 > L6 & L1 > 0 & L4 > 0 & L7 > L8 & L8 > L9 & L9 > L10")

######################Regression coefficients########################

options(digits = 3)
strest2 <- standardizedSolution(fit)[11:14, 4]
strcovmtrx2 <- lavInspect(fit, "vcov.std.all")[11:14, 11:14]
names(strest2) <- colnames(strcovmtrx2)
strest2

strcovmtrx2

set.seed(111)
names(strest2) <- c("G1", "G2", "G3", "G4")
gorica(x = strest2, Sigma = strcovmtrx2,
       hypothesis = "G1 > G3 & G3 > 0;
G1 > G3 & G3 > 0 & G2 > 0 & -G4 > 0")


##################Covariance between latent variables####################


strest3 <- standardizedSolution(fit)[25, 4]
strcovmtrx3<-matrix(c(lavInspect(fit, "vcov.std.all")[23, 23]))
names(strest3) <- colnames(lavInspect(fit, "vcov.std.all"))[23]
rownames(strcovmtrx3) <- colnames(lavInspect(fit, "vcov.std.all"))[23]
colnames(strcovmtrx3) <- colnames(lavInspect(fit, "vcov.std.all"))[23]
strest3

strcovmtrx3

set.seed(111)
names(strest3) <- c("w21")
gorica(x = strest3, Sigma = strcovmtrx3,
       hypothesis = "w21 = 0;
w21 > 0;
-w21 > 0", comparison = "none")






