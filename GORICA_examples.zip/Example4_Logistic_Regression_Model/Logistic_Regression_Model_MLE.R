library(easypackages)
list.of.packages <- c("base", "blavaan", "boot", "coda", "foreign",
                      "FRACTION", "lavaan", "lme4", "MASS", "matrixcalc", "mvtnorm", "nlme",
                      "quadprog", "R2OpenBUGS", "gorica","elrm")
new.packages <- list.of.packages[!(list.of.packages %in%
                                     installed.packages()[, "Package"])]
if (length(new.packages)) install.packages(new.packages)
libraries(list.of.packages)


dat <- read.table(text = "
female  apcalc    admit       num
0        0        0         7
0        0        1         1
0        1        0         3
0        1        1         7
1        0        0         5
1        0        1         1
1        1        0         0
1        1        1         6",
                  header = TRUE)

mydata<-dat[rep(1:nrow(dat), dat$num), -4]
mydata

####Maximum Likelihood Estimation####
model1 <- glm(admit ~ female + apcalc,family = "binomial",data=mydata)
strest<-model1$coefficients
strest

strcovmtrx <- vcov(model1)
strcovmtrx


set.seed(111)
names(strest) <- c("B0","B1","B2")
gorica(x = strest, Sigma=strcovmtrx,
       hypothesis = "B2 > 0; B1 > 0; B2>0 & -B1>0")
