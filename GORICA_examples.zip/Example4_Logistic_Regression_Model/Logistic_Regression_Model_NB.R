library(easypackages)
list.of.packages <- c("base", "blavaan", "boot", "coda", "foreign",
                      "FRACTION", "lavaan", "lme4", "MASS", "matrixcalc", "mvtnorm", "nlme",
                      "quadprog", "R2OpenBUGS", "gorica","elrm")
new.packages <- list.of.packages[!(list.of.packages %in%
                                     installed.packages()[, "Package"])]
if (length(new.packages)) install.packages(new.packages)
libraries(list.of.packages)


dat <- read.table(text = "
female  apcalc    admit       num
0        0        0         7
0        0        1         1
0        1        0         3
0        1        1         7
1        0        0         5
1        0        1         1
1        1        0         0
1        1        1         6",
                  header = TRUE)

mydata<-dat[rep(1:nrow(dat), dat$num), -4]
mydata



set.seed(111)
boot.fn <- function(data, index) {
  return(coef(glm(admit ~ female + apcalc,
                  family = c("binomial"), data = mydata, subset = index) ) ) }
boot_sim <- boot(mydata, boot.fn, R = 1000, sim = "ordinary")

colnames(boot_sim$t) <- names(boot_sim$t0)
strest <- apply(boot_sim$t, 2, mean)[c(1, 2, 3)]
strest

strcovmtrx <- cov(boot_sim$t)
strcovmtrx


set.seed(111)
names(strest) <- c("B0","B1","B2")
gorica(x = strest, Sigma=strcovmtrx,
       hypothesis = "B2 > 0; B1 > 0; B2>0 & -B1>0")
