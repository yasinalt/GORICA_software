library(easypackages)
list.of.packages <- c("base", "blavaan", "boot", "coda", "foreign",
                      "FRACTION", "lavaan", "lme4", "MASS", "matrixcalc", "mvtnorm", "nlme",
                      "quadprog", "R2OpenBUGS", "gorica","elrm")
new.packages <- list.of.packages[!(list.of.packages %in%
                                     installed.packages()[, "Package"])]
if (length(new.packages)) install.packages(new.packages)
libraries(list.of.packages)


dat <- read.table(text = "
female  apcalc    admit       num
0        0        0         7
0        0        1         1
0        1        0         3
0        1        1         7
1        0        0         5
1        0        1         1
1        1        0         0
1        1        1         6",
                  header = TRUE)

mydata<-dat[rep(1:nrow(dat), dat$num), -4]
mydata



N <- nrow(mydata)
female<-mydata$female
apcalc<-mydata$apcalc
admit<-mydata$admit


mydata <- list("N", "female", "apcalc", "admit")
beta0 <- c(rnorm(1, 0, 1e-05))
beta <- c(rnorm(2, 0, 1e-05))
inits <- function(){list(beta0 = beta0, beta = beta) }

gibbs.sim <- bugs(mydata, inits, model.file = "bugs_logistic.txt",
                  parameters = c("beta0", "beta"), n.chains = 3, n.iter = 30000,
                  n.burnin = 3000, debug = TRUE, codaPkg = TRUE)


codaobject <- as.matrix(read.bugs(gibbs.sim) )
colnames(codaobject) <- c("female", "apcalc", "Intercept","deviance")
strest <- apply(codaobject, 2, mean)[c(3,1,2)]
strest


strcovmtrx <- cov(codaobject)[c(3, 1, 2), c(3, 1, 2)]
strcovmtrx

set.seed(111)
names(strest) <- c("B0","B1","B2")
gorica(x = strest, Sigma=strcovmtrx,
       hypothesis = "B2 > 0; B1 > 0; B2>0 & -B1>0")