library(easypackages)
list.of.packages <- c("base", "blavaan", "boot", "coda", "foreign",
                      "FRACTION", "lavaan", "lme4", "MASS", "matrixcalc", "mvtnorm", "nlme",
                      "quadprog", "R2OpenBUGS", "gorica")
new.packages <- list.of.packages[!(list.of.packages %in%
                                     installed.packages()[, "Package"])]
if (length(new.packages)) install.packages(new.packages)
libraries(list.of.packages)


academic_awards <- read.csv("academic_awards.csv")
academic_awards <- within(academic_awards, {
  prog <- factor(prog, levels = 1:3,
                 labels = c("General", "Academic", "Vocational") ) } )
zmath <- scale(academic_awards$math)
model <- glm(num_awards ~ prog + zmath + prog * zmath, family = "poisson",
             data = academic_awards)
model

strest <- model$coefficients[c(4, 5, 6)]
strest
strcovmtrx <- vcov(model)[c(4, 5, 6), c(4, 5, 6)]
strcovmtrx

set.seed(111)
names(strest) <- c("B3","B4","B5")
gorica(x = strest, Sigma=strcovmtrx,
       hypothesis = "B3 = B3+B4 & B3 = B3+B5 & B3 = 0;
B3+B4 > B3+B5 & B3+B5 > B3;
B3+B4-B3-B5 > B3+B4-B3")



