library(easypackages)
list.of.packages <- c("base", "blavaan", "boot", "coda", "foreign",
                      "FRACTION", "lavaan", "lme4", "MASS", "matrixcalc", "mvtnorm", "nlme",
                      "quadprog", "R2OpenBUGS", "gorica")
new.packages <- list.of.packages[!(list.of.packages %in%
                                     installed.packages()[, "Package"])]
if (length(new.packages)) install.packages(new.packages)
libraries(list.of.packages)

academic_awards <- read.csv("academic_awards.csv")
academic_awards <- within(academic_awards, {
  prog <- factor(prog, levels = 1:3,
                 labels = c("General", "Academic", "Vocational") ) } )
zmath <- scale(academic_awards$math)


set.seed(111)
boot.fn <- function(data, index) {
  return(coef(glm(num_awards ~ prog + zmath + prog * zmath,
                  family = c("poisson"), data = academic_awards, subset = index) ) ) }
boot_sim <- boot(academic_awards, boot.fn, R = 1000, sim = "ordinary")

colnames(boot_sim$t) <- names(boot_sim$t0)
strest <- apply(boot_sim$t, 2, mean)[c(4, 5, 6)]
strest

strcovmtrx <- cov(boot_sim$t)[c(4, 5, 6), c(4, 5, 6)]
strcovmtrx

set.seed(111)
names(strest) <- c("B3","B4","B5")
gorica(x = strest, Sigma=strcovmtrx,
       hypothesis = "B3 = B3+B4 & B3 = B3+B5 & B3 = 0;
B3+B4 > B3+B5 & B3+B5 > B3;
B3+B4-B3-B5 > B3+B4-B3")



