library(easypackages)
list.of.packages <- c("base", "blavaan", "boot", "coda", "foreign",
                      "FRACTION", "lavaan", "lme4", "MASS", "matrixcalc", "mvtnorm", "nlme",
                      "quadprog", "R2OpenBUGS", "gorica")
new.packages <- list.of.packages[!(list.of.packages %in%
                                     installed.packages()[, "Package"])]
if (length(new.packages)) install.packages(new.packages)
libraries(list.of.packages)

academic_awards <- read.csv("academic_awards.csv")
academic_awards <- within(academic_awards, {
  prog <- factor(prog, levels = 1:3,
                 labels = c("General", "Academic", "Vocational") ) } )
zmath <- scale(academic_awards$math)


N <- nrow(academic_awards)
prog <- academic_awards$prog
academic <- model.matrix(~ prog)[, 2]
vocational <- model.matrix(~ prog)[, 3]
zmath <- as.numeric(zmath)
num_awards <- as.numeric(academic_awards$num_awards)
data <- list("N", "academic", "vocational", "zmath", "num_awards")
beta0 <- c(rnorm(1, 0, 1e-05))
beta <- c(rnorm(5, 0, 1e-05))
inits <- function(){list(beta0 = beta0, beta = beta) }

gibbs.sim <- bugs(data, inits, model.file = "bugsmodelglm.txt",
                  parameters = c("beta0", "beta"), n.chains = 3, n.iter = 30000,
                  n.burnin = 3000, debug = TRUE, codaPkg = TRUE)

codaobject <- as.matrix(read.bugs(gibbs.sim) )
colnames(codaobject) <- c("progAcademic", "progVocational", "zmath",
                          "progAcademic:zmath", "progVocational:zmath", "Intercept", "deviance")
strest <- apply(codaobject, 2, mean)[c(3, 4, 5)]
strest

strcovmtrx <- cov(codaobject)[c(3, 4, 5), c(3, 4, 5)]
strcovmtrx

names(strest) <- c("B3","B4","B5")
gorica(x = strest, Sigma=strcovmtrx,
       hypothesis = "B3 = B3+B4 & B3 = B3+B5 & B3 = 0;
B3+B4 > B3+B5 & B3+B5 > B3;
B3+B4-B3-B5 > B3+B4-B3")

