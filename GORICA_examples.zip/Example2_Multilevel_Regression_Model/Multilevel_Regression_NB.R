library(easypackages)
list.of.packages <- c("base", "blavaan", "boot", "coda", "foreign",
                      "FRACTION", "lavaan", "lme4", "MASS", "matrixcalc", "mvtnorm", "nlme",
                      "quadprog", "R2OpenBUGS", "gorica")
new.packages <- list.of.packages[!(list.of.packages %in%
                                     installed.packages()[, "Package"])]
if (length(new.packages)) install.packages(new.packages)
libraries(list.of.packages)



data(reading_ach)
zgeread <- scale(reading_ach$geread)
zage <- scale(reading_ach$age)
zgevocab <- scale(reading_ach$gevocab)
reading_ach$gender <- as.factor(reading_ach$gender)
model <- lmer(zgeread ~ zage + zgevocab + gender + zage * zgevocab +
                zage * gender + zgevocab * gender + (1 + zgevocab | school),
              data = reading_ach, REML = FALSE)
model

set.seed(111)
source("covglmm.txt")
covar <- covglmm(lmer(geread ~ age + gevocab + gender + age * gevocab +
                        age * gender + gevocab * gender + (1 + gevocab | school), data = reading_ach,
                      REML = FALSE), B = 1000, cluster = c(1), fact = c(2), std = c(3, 4, 5) )
covar


colnames(covar$boot) <- names(summary(model)$coefficients[, 1] )
strest <- apply(covar$boot, 2, mean)[c(2, 3, 5, 6, 7)]
strest


strcovmtrx <- cov(covar$boot)[c(2, 3, 5, 6, 7), c(2, 3, 5, 6, 7)]
strcovmtrx

set.seed(111)
names(strest) <- c("B1","B2","B4","B5","B6")
gorica(x = strest, Sigma=strcovmtrx,
       hypothesis = "B1 = 0 & B2 > 0 & B1+B5 = 0 & B2+B6 > 0 & B4 > 0;
-B1 > 0 & B2 > 0 & -B1-B5 > 0 & B2+B6 > 0 & B4 > 0;
B1 > 0 & B2 > 0 & -B1-B5 > 0 & -B2-B6 > 0 & B4 = 0")