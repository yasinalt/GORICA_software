library(easypackages)
list.of.packages <- c("base", "blavaan", "boot", "coda", "foreign",
                      "FRACTION", "lavaan", "lme4", "MASS", "matrixcalc", "mvtnorm", "nlme",
                      "quadprog", "R2OpenBUGS", "gorica")
new.packages <- list.of.packages[!(list.of.packages %in%
                                     installed.packages()[, "Package"])]
if (length(new.packages)) install.packages(new.packages)
libraries(list.of.packages)


set.seed(111)
data(reading_ach)
zgeread <- scale(reading_ach$geread)
zage <- scale(reading_ach$age)
zgevocab <- scale(reading_ach$gevocab)
reading_ach$gender <- as.factor(reading_ach$gender)
model <- lmer(zgeread ~ zage + zgevocab + gender + zage * zgevocab +
                zage * gender + zgevocab * gender + (1 + zgevocab | school),
              data = reading_ach, REML = FALSE)
model

strest <- summary(model)$coefficients[c(2, 3, 5, 6, 7), 1]
strest
strcovmtrx <- vcov(model)[c(2, 3, 5, 6, 7), c(2, 3, 5, 6, 7)]
strcovmtrx

set.seed(111)
names(strest) <- c("B1","B2","B4","B5","B6")
gorica(x = strest, Sigma=strcovmtrx,
       hypothesis = "B1 = 0 & B2 > 0 & B1+B5 = 0 & B2+B6 > 0 & B4 > 0;
-B1 > 0 & B2 > 0 & -B1-B5 > 0 & B2+B6 > 0 & B4 > 0;
B1 > 0 & B2 > 0 & -B1-B5 > 0 & -B2-B6 > 0 & B4 = 0")



