library(easypackages)
list.of.packages <- c("base", "blavaan", "boot", "coda", "foreign",
                      "FRACTION", "lavaan", "lme4", "MASS", "matrixcalc", "mvtnorm", "nlme",
                      "quadprog", "R2OpenBUGS", "gorica")
new.packages <- list.of.packages[!(list.of.packages %in%
                                     installed.packages()[, "Package"])]
if (length(new.packages)) install.packages(new.packages)
libraries(list.of.packages)


set.seed(111)
data(reading_ach)
N <- nrow(reading_ach)
school <- reading_ach[, 1]
gender <- model.matrix(~ factor(reading_ach$gender))[, 2]
zage <- as.numeric(scale(reading_ach$age))
zgevocab <- as.numeric(scale(reading_ach$gevocab))
zgeread <- as.numeric(scale(reading_ach$geread))
data <- list("N", "school", "gender", "zage", "zgevocab", "zgeread")


beta0 <- c(rnorm(1, 0, 1e-05))
beta <- c(rnorm(6, 0, 1e-05))
inits <- function(){
  list(beta0 = beta0, beta = beta, prec.sigma2 = 1, prec.tau2 = 1) }
gibbs.sim <- bugs(data, inits, model.file = "bugsmodelglmm.txt",
                  parameters = c("beta0", "beta", "prec.sigma2", "prec.tau2"),
                  n.iter = 10000, n.burnin = 1000, n.chains = 3, debug = TRUE,
                  codaPkg = TRUE)
codaobject <- as.matrix(read.bugs(gibbs.sim))
colnames(codaobject)<-c("zage", "zgevocab", "genderMale", "zage:zgevocab",
                        "zage:genderMale", "zgevocab:genderMale", "Intercept","deviance","prec.sigma2",
                        "prec.tau2")


strest <- apply(codaobject, 2, mean)[c(1, 2, 4, 5, 6)]
strest


strcovmtrx <- cov(codaobject)[c(1, 2, 4, 5, 6), c(1, 2, 4, 5, 6)]
strcovmtrx


names(strest) <- c("B1","B2","B4","B5","B6")
gorica(x = strest, Sigma=strcovmtrx,
       hypothesis = "B1 = 0 & B2 > 0 & B1+B5 = 0 & B2+B6 > 0 & B4 > 0;
-B1 > 0 & B2 > 0 & -B1-B5 > 0 & B2+B6 > 0 & B4 > 0;
B1 > 0 & B2 > 0 & -B1-B5 > 0 & -B2-B6 > 0 & B4 = 0")

